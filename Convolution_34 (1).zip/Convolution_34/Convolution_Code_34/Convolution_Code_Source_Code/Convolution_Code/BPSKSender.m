function input=BPSKSender(input,maxV)
input(:)=(2*maxV)*input(:)-maxV;
end